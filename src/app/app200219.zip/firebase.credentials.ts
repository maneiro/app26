
  export const FIREBASE_CREDENTIALS = {
    apiKey: "AIzaSyD5sH0p9rfb6ttOrdacifDB4TDK6eIGcfc",
    authDomain: "prueba2-ale1.firebaseapp.com",
    databaseURL: "https://prueba2-ale1.firebaseio.com",
    projectId: "prueba2-ale1",
    storageBucket: "prueba2-ale1.appspot.com",
    messagingSenderId: "723863873685"
  };

  

