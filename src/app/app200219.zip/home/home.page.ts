import { Component } from '@angular/core';

import { AngularFireDatabase } from '@angular/fire/database';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import {CuentasService} from '../services/cuentas.service';
// import * as firebase from 'firebase/app';
import * as moment from 'moment';
import { Events } from '@ionic/angular';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

// import {CuentasList} from '../models/CuentasList/CuentasList.interface';
import {Filter2Pipe} from '../pipes/filter2.pipe';
export interface Item { nombre: string; cuenta:string}
export interface iface_tran { debe: string; haber:string; importe: number; timestamp:any}
// import {CuentasService} from "../cuentas.service";
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  
})

export class HomePage {

 // cuentas = {} as CuentasList;

 
 items: Observable<any[]>;
 tran : Observable<any[]>;
 valor: Observable<any>;
 tranForm:iface_tran;
 sfDocRef:any;
 private itemsCollection: AngularFirestoreCollection<Item>;
 private tranCollection: AngularFirestoreCollection<iface_tran>;
 itemfire: Observable<Item[]>;
 grupo:any[];
 cities:any[];
 // dataRef$: FirebaseListObservable<CuentasList[]>

constructor (private db: AngularFireDatabase, public afs: AngularFirestore, public ctaservice:CuentasService, public events: Events){
    // this.dataRef$ = this.db.list('cuentas');
    // this.items = db.collection('items').valueChanges();
    this.items = db.list('cuentas').valueChanges();
    this.itemsCollection = afs.collection<Item>('cuentas');
    this.itemfire = this.itemsCollection.valueChanges();
    // this.dataRef$.subscribe (x => console.log(X) );
    this.tranCollection = afs.collection<iface_tran>('tran', ref => ref.orderBy('timestamp') ); 
    // this.tranCollection = afs.collection<iface_tran>('tran', ref => ref.where("timestamp", "<", "1549371600000" ));   //("haber", "==","124")); 
    this.tran = this.tranCollection.valueChanges();

    this.tran= afs.collection("tran", ref => ref.where("lista","==","X")) .valueChanges() ;//).doc(id).update({ 

    this.valor = this.tranCollection.snapshotChanges().pipe(
                    map(actions => actions.map(a => {
                      const data = a.payload.doc.data();
                      const id = a.payload.doc.id;
                      // console.log ("LOGid: ",id );
                      // console.log ("LOGdata: ",data ); 

                      /*afs.collection("tran").doc(id).update({
                              "lista": "A",                
                      });*/

                     /* if (id=="PViObLk1qvjKcMi3VJRM" ){
                          afs.collection("tran").doc(id).update({
                              "debe": "502",
                              "favorites.color": "azul"
                            }).then(function() {
                            console.log("Document successfully updated!");
                          });
                          // console.log("atenti:",afs.collection('tran'));
                       }*/
                          console.log ("<LOG>: ",{ id, ...data });
                          console.log ('TRAN--> ',this.tran);
                          return { id, ...data };
            })));
      
    this.valor.subscribe({
      next(num) { console.log("data seq:",num,"*** num records:",num.length);                      
                 this.cities = [];
                 this.cities.push(num);
                 console.log("cities: ",this.cities);
               },
      complete() { console.log('* Finished sequence *') }
    });

    this.tranForm={} as iface_tran;

    this.grupo=[  {  "cuenta": "502",   "nombre": "Gastos"}  ];


    this.events.subscribe('testevent', (data) => {
      console.log('testevent');
      console.log(data);
    //  appPages.push( {
    //   title: 'listado',
    //   url: '/list',
    //   icon: 'star'
    // });
    //   console.log(appPages);
    });



}


 
 addTran () {
let a= moment().valueOf(); //.format('DD/MM/YY');
// console.log("A: " ,a);

    this.tranCollection.add({ debe: this.tranForm.debe, haber: this.tranForm.haber, importe: this.tranForm.importe , timestamp:a });
    // firebase.firestore.FieldValue.serverTimestamp()
    
}

procesar (){
  this.sfDocRef= this.afs.collection('tran').doc('PViObLk1qvjKcMi3VJRM');
  console.log(this.sfDocRef);
this.grupo= [...this.grupo, ...(this.ctaservice.leer ())];
    console.log('shouldPublishEvent');
    this.events.publish('testevent', {key: 'actualizar'});
 // this.ctaservice.leer();
    /*this.sfDocRef.onSnapshot(function(querySnapshot) {
        var cities = [];
        querySnapshot.forEach(function(doc) {
            cities.push(doc.data().name);
        });
        console.log("Current cities in CA: ", cities.join(", "));
    });*/

      /* this.afs.runTransaction(function(transaction) {
        // This code may get re-run multiple times if there are conflicts.
        sfDocRef= afs.collection('tran').doc('PViObLk1qvjKcMi3VJRM');
        return transaction.get(sfDocRef).then(function(sfDoc) {
            if (!sfDoc.exists) {
                throw "Document does not exist!";
            }

            console.log ("importe en transaction: ", sfDoc.data().importe);
            transaction.update(sfDocRef, { debe: "594" });
        });
    }).then(function() {
        console.log("Transaction successfully committed!");
    }).catch(function(error) {
        console.log("Transaction failed: ", error);
    });*/
}

}
