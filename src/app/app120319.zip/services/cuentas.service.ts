import { Injectable } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/database';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class CuentasService {

  constructor( private db: AngularFireDatabase) { 


  }

  getItems() {
  		return this.db.list('cuentas').valueChanges();

  }


  leer (){
   return [ {"cuenta": "111",    "nombre": "Caja"},
            {"cuenta": "124",    "nombre": "St George bank"},
            {"cuenta": "214",    "nombre": "AGL electricidad"}
   ]       
 }


}
