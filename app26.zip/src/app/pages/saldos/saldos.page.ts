import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saldos',
  templateUrl: './saldos.page.html',
  styleUrls: ['./saldos.page.scss'],
})
export class SaldosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
